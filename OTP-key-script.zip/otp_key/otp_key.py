#!/usr/bin/env python3
"""
Generate OTP (One-Time Password) keys and codes.
Stores secrets in an encrypted file (password-protected).
Uses only Python standard library + system OpenSSL - no pip install.
"""

import argparse
import base64
import getpass
import hashlib
import hmac
import json
import os
import secrets
import struct
import subprocess
import sys
import tempfile
import time

SECRETS_FILE = os.path.join(os.path.dirname(__file__), "otp_secrets.enc")
CACHE_FILE = os.path.join(os.path.dirname(__file__), ".otp_cache")
CACHE_TTL_SECONDS = 15 * 60  # 15 minutes


def generate_secret_key(length: int = 16) -> str:
    """Generate a secure random base32-encoded secret key for OTP."""
    raw = secrets.token_bytes(length)
    return base64.b32encode(raw).decode("ascii").rstrip("=")


def get_totp_code(secret: str, timestamp: int | None = None) -> str:
    """
    Generate current TOTP code (6 digits) from a base32 secret.
    Compatible with Google Authenticator, Authy, etc.
    """
    if timestamp is None:
        timestamp = int(time.time())
    counter = timestamp // 30

    try:
        key = base64.b32decode(secret + "=" * (8 - len(secret) % 8))
    except Exception:
        key = base64.b32decode(secret)

    counter_bytes = struct.pack(">Q", counter)
    h = hmac.new(key, counter_bytes, hashlib.sha1).digest()
    offset = h[-1] & 0x0F
    code = struct.unpack(">I", h[offset : offset + 4])[0] & 0x7FFFFFFF
    return f"{code % 1_000_000:06d}"


def get_remaining_seconds() -> int:
    """Seconds left before the current TOTP code changes (0–29)."""
    return 30 - (int(time.time()) % 30)


def get_next_totp_code(secret: str) -> str:
    """Return the OTP code that will appear when the current 30s window ends."""
    t = int(time.time())
    next_ts = (t // 30 + 1) * 30
    return get_totp_code(secret, next_ts)


def _run_openssl(args: list[str], input_data: bytes, password: str) -> bytes:
    """Run openssl, passing the password via a temp file (so it is not in argv)."""
    # Write password to a temporary file so OpenSSL can read it via -pass file:...
    pw_path = None
    try:
        with tempfile.NamedTemporaryFile("w", delete=False) as pw_file:
            pw_file.write(password)
            pw_file.flush()
            pw_path = pw_file.name

        proc = subprocess.Popen(
            [
                "openssl",
                "enc",
                "-aes-256-cbc",
                "-salt",
                "-pbkdf2",
                "-base64",
                "-pass",
                f"file:{pw_path}",
            ]
            + args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        out, err = proc.communicate(input=input_data)
        if proc.returncode != 0:
            raise RuntimeError(f"OpenSSL failed: {err.decode()}")
        return out
    finally:
        if pw_path and os.path.exists(pw_path):
            try:
                os.remove(pw_path)
            except OSError:
                pass


def save_secrets(secrets_dict: dict, password: str) -> None:
    """Save secrets to encrypted file."""
    data = json.dumps(secrets_dict).encode()
    encrypted = _run_openssl(["-e"], data, password)
    with open(SECRETS_FILE, "wb") as f:
        f.write(encrypted)
    os.chmod(SECRETS_FILE, 0o600)
    print(f"Saved to {SECRETS_FILE}")


def load_secrets(password: str) -> dict:
    """Load secrets from encrypted file."""
    if not os.path.exists(SECRETS_FILE):
        return {}
    with open(SECRETS_FILE, "rb") as f:
        encrypted = f.read()
    try:
        decrypted = _run_openssl(["-d"], encrypted, password)
    except RuntimeError as e:
        raise RuntimeError(
            "Could not decrypt existing secrets file. This usually means:\n"
            "- you typed a different password than the one used originally, or\n"
            "- the file was created by an older/broken version.\n\n"
            f"Fix: delete/rename `{SECRETS_FILE}` and run `python3 otp_key.py --add <name>` again.\n"
        ) from e
    try:
        return json.loads(decrypted.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise RuntimeError(
            "Decrypted data is invalid. Almost always this means you used the wrong password.\n"
            "Use the same password you set when you ran --add.\n\n"
            "If you forgot it, run:  python3 otp_key.py --reset   then  python3 otp_key.py --add gitlab\n"
        ) from e


def get_cached_secrets() -> dict | None:
    """Return decrypted secrets from cache if still valid, else None."""
    if not os.path.exists(CACHE_FILE):
        return None
    try:
        with open(CACHE_FILE, "rb") as f:
            data = f.read()
    except OSError:
        return None
    idx = data.find(b"\n")
    if idx < 0:
        return None
    try:
        cached_at = int(data[:idx].decode())
    except (ValueError, UnicodeDecodeError):
        return None
    if time.time() - cached_at > CACHE_TTL_SECONDS:
        try:
            os.remove(CACHE_FILE)
        except OSError:
            pass
        return None
    try:
        return json.loads(data[idx + 1 :].decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


def save_secrets_cache(secrets_dict: dict) -> None:
    """Write secrets to cache file (plaintext, 15 min TTL)."""
    with open(CACHE_FILE, "wb") as f:
        f.write(str(int(time.time())).encode() + b"\n")
        f.write(json.dumps(secrets_dict).encode())
    os.chmod(CACHE_FILE, 0o600)


def main():
    parser = argparse.ArgumentParser(description="OTP key generator with secure storage")
    parser.add_argument("--add", "-a", metavar="NAME", help="Add new key (e.g. 'github', 'gmail')")
    parser.add_argument("--list", "-l", action="store_true", help="List stored keys and show codes")
    parser.add_argument("--generate", "-g", action="store_true", help="Generate new key (print only, no save)")
    parser.add_argument("--reset", action="store_true", help="Remove encrypted file and start fresh (use if decrypt fails)")
    args = parser.parse_args()

    if args.reset:
        if os.path.exists(SECRETS_FILE):
            os.remove(SECRETS_FILE)
            print(f"Removed {SECRETS_FILE}. Run --add to create a new key.")
        else:
            print("No secrets file found. Nothing to reset.")
        if os.path.exists(CACHE_FILE):
            os.remove(CACHE_FILE)
        return

    if args.generate:
        secret = generate_secret_key()
        code = get_totp_code(secret)
        print("=" * 40)
        print("OTP Secret Key (add to authenticator app):")
        print(secret)
        print()
        print("Current OTP code (valid ~30 seconds):")
        print(code)
        print("=" * 40)
        return

    if args.add:
        name = args.add.strip().lower()
        if not name:
            print("Error: name cannot be empty", file=sys.stderr)
            sys.exit(1)
        password = getpass.getpass("Password to encrypt storage: ")
        try:
            secrets_dict = load_secrets(password)
        except RuntimeError:
            secrets_dict = {}
            print("Existing file could not be decrypted; starting fresh.", file=sys.stderr)
        if name in secrets_dict:
            print(f"Key '{name}' already exists. Use a different name.", file=sys.stderr)
            sys.exit(1)
        raw = input(f"Paste your OTP secret for '{name}' (from GitLab/etc), or press Enter to generate a new one: ").strip().upper().replace(" ", "")
        if raw:
            secret = raw
            # Validate: base32 alphabet
            try:
                get_totp_code(secret)
            except Exception:
                print("Error: that doesn't look like a valid OTP secret.", file=sys.stderr)
                sys.exit(1)
        else:
            secret = generate_secret_key()
            print("Generated new secret. Add it to your authenticator app if needed.")
        secrets_dict[name] = secret
        save_secrets(secrets_dict, password)
        print(f"Added '{name}'. Current code: {get_totp_code(secret)}")
        return

    if args.list:
        secrets_dict = get_cached_secrets()
        if secrets_dict is None:
            password = getpass.getpass("Password: ")
            try:
                secrets_dict = load_secrets(password)
            except RuntimeError as e:
                print(e, file=sys.stderr)
                print("Run:  python3 otp_key.py --reset   then  python3 otp_key.py --add gitlab", file=sys.stderr)
                sys.exit(1)
            save_secrets_cache(secrets_dict)
        if not secrets_dict:
            print("No keys stored. Use --add NAME to add one.")
            return
        print("=" * 40)
        remaining = get_remaining_seconds()
        for name, secret in secrets_dict.items():
            print(f"{name}: {get_totp_code(secret)}  ({remaining}s)  → next: {get_next_totp_code(secret)}")
        print("=" * 40)
        return

    # Default: list (show codes)
    secrets_dict = get_cached_secrets()
    if secrets_dict is None:
        password = getpass.getpass("Password: ")
        try:
            secrets_dict = load_secrets(password)
        except RuntimeError as e:
            print(e, file=sys.stderr)
            print("Run:  python3 otp_key.py --reset   then  python3 otp_key.py --add gitlab", file=sys.stderr)
            sys.exit(1)
        save_secrets_cache(secrets_dict)
    if not secrets_dict:
        print("No keys stored. Use --add NAME to add one.")
        print("  python otp_key.py --add github")
        return
    print("=" * 40)
    remaining = get_remaining_seconds()
    for name, secret in secrets_dict.items():
        print(f"{name}: {get_totp_code(secret)}  ({remaining}s)  → next: {get_next_totp_code(secret)}")
    print("=" * 40)


if __name__ == "__main__":
    main()
