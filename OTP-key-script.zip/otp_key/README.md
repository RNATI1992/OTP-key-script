# OTP Key

Store your OTP secrets (GitLab, Redmine, etc.) and get current codes from the terminal. No extra installs: Python 3 + OpenSSL only.

## Setup

- Python 3
- OpenSSL (usually already on Linux/macOS)

## Usage

```bash
# Add a key (paste the secret from your service when asked)
python3 otp_key.py --add gitlab
python3 otp_key.py --add redmine

# Show all codes (password asked once, then cached 15 min)
python3 otp_key.py --list
# or
python3 otp_key.py

# Generate a new secret (e.g. for a new service)
python3 otp_key.py --generate

# Start over (removes encrypted file and cache)
python3 otp_key.py --reset
```

## First time

1. Run `python3 otp_key.py --add myservice`
2. Enter a **password** (you choose it; same one every time for this script)
3. When asked, **paste the OTP secret** from your service (GitLab, etc.) or press Enter to generate one
4. Use `python3 otp_key.py --list` to see codes; use the same password when asked

Secrets are stored encrypted in `otp_secrets.enc` in this folder. Do not share that file.
